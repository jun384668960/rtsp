#ifndef __CAMERA_H__
#define __CAMERA_H__ 

#ifdef __cplusplus
extern "C" {
#endif




int camera_init(void);
int camera_exit(void);




#ifdef __cplusplus
}
#endif

#endif

