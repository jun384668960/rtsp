#ifndef __PS3210_API_H__
#define __PS3210_API_H__ 

#ifdef __cplusplus
extern "C" {
#endif

#include "public_api.h"

extern const public_sensor_interface_st PS3210k_sensor;



#ifdef __cplusplus
}
#endif

#endif


