#include "P2pSource.hh"
#include "utils_log.h"

CP2pSouce* CP2pSouce::instance = NULL;

CP2pSouce::CP2pSouce()
{

}

CP2pSouce::~CP2pSouce()
{

}

CP2pSouce* CP2pSouce::GetInstance()
{
	if(instance == NULL)
	{
		instance = new CP2pSouce();
	}

	return instance;
}


GssLiveConn* CP2pSouce::newCreateClient(string uid, char* server, int port)
{
//	std::map<string, GssLiveConn*>::iterator it;

//	it = m_P2pClnts.find(uid);
//	if(it != m_P2pClnts.end())
//	{
//		LOGI_print("Exist clnt:%p m_P2pClnts size:%d", it->second, m_P2pClnts.size());
//		return it->second;
//	}
//	else
	{
		GssLiveConn* clnt = new GssLiveConn(server, port, uid.c_str());
		m_P2pClnts.insert(std::pair<string, GssLiveConn*>(uid, clnt));

		LOGI_print("clnt:%p m_P2pClnts size:%d", clnt, m_P2pClnts.size());
		return clnt;
	}
}

int CP2pSouce::delCreateClient(string uid)
{
	std::map<string, GssLiveConn*>::iterator it;

	it = m_P2pClnts.find(uid);
	if(it != m_P2pClnts.end())
	{
		delete it->second;
		m_P2pClnts.erase (it);
	}

	LOGI_print("m_P2pClnts size:%d", m_P2pClnts.size());
	return 0;
}

