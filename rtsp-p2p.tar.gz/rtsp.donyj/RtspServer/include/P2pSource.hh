#ifndef P2P_SOURCE
#define P2P_SOURCE
#include <map>
#include <string>

#include "GssLiveConn.h"

using namespace std;

class CP2pSouce
{
public:
	CP2pSouce();
	~CP2pSouce();

	static CP2pSouce* GetInstance();
	static CP2pSouce* instance;

	GssLiveConn* newCreateClient(string uid, char* server, int port);
	int delCreateClient(string uid);
	
private:
	map<string, GssLiveConn*> 	m_P2pClnts;
	int							m_refDel;
};

#endif
