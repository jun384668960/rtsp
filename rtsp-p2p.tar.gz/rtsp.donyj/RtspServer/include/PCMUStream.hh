#ifndef _PCMU_STREAM_HH
#define _PCMU_STREAM_HH

#include "FramedSource.hh"
#include "OnDemandServerMediaSubsession.hh"
#include "SimpleRTPSink.hh"
#include "GssLiveConn.h"

class PCMUStream: public FramedSource {
public:
	static PCMUStream* createNew(UsageEnvironment& env, GssLiveConn* liveConn);
	unsigned samplingFrequency() const { return fSamplingFrequency; }
	unsigned numChannels() const { return fNumChannels; }
	char const* configStr() const { return fConfigStr; }
	// returns the 'AudioSpecificConfig' for this stream (in ASCII form)

private:
	PCMUStream(UsageEnvironment& env, GssLiveConn* liveConn, u_int8_t profile,u_int8_t samplingFrequencyIndex, u_int8_t channelConfiguration);
	// called only by createNew()
	virtual ~PCMUStream();

	static void incomingDataHandler(PCMUStream* source);
	void incomingDataHandler1();

private:
	// redefined virtual functions:
	virtual void doGetNextFrame();

private:
	unsigned fSamplingFrequency;
	unsigned fNumChannels;
	unsigned fuSecsPerFrame;
	char fConfigStr[5];
    GssLiveConn* m_LiveSource;
	unsigned int m_ref;
};



class PCMUServerMediaSubsession: public OnDemandServerMediaSubsession{
public:
	static PCMUServerMediaSubsession* createNew(UsageEnvironment& env, GssLiveConn* liveConn, Boolean reuseFirstSource);
protected:
	PCMUServerMediaSubsession(UsageEnvironment& env, GssLiveConn* liveConn, Boolean reuseFirstSource);
	// called only by createNew();
	virtual ~ PCMUServerMediaSubsession();

protected: // redefined virtual functions
	virtual FramedSource* createNewStreamSource(unsigned clientSessionId,unsigned& estBitrate);
	virtual RTPSink* createNewRTPSink(Groupsock* rtpGroupsock,
                		unsigned char rtpPayloadTypeIfDynamic,
				       	FramedSource* inputSource);
	GssLiveConn* m_LiveConn;
};

#endif
