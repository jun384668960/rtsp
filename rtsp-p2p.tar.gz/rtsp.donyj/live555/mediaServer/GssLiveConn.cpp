﻿#include "GssLiveConn.h"
#include "gss_transport.h" 
#include "gss_common.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

GssLiveConn::GssLiveConn()
{
	memset(m_server,0,sizeof(m_server));
	memset(m_uid,0,sizeof(m_uid));
	memset(m_bufferVideo, 0, MAX_AV_SIZE*sizeof(GssBuffer*));
	memset(m_bufferAudio, 0, MAX_AV_SIZE*sizeof(GssBuffer*));
	m_currNextIndexVideoInsert = 0;
	m_countsVideo = 0;
	m_curVideoIndex = 0;
	m_currNextIndexAudioInsert = 0;
	m_countsAudio = 0;
	m_curAudioIndex = 0;
	m_port = 0;
	m_isConnected = false;
	m_clientPullConn = NULL;
	m_stusRlt = 0;

	InitVideoBuffer();
	InitAudioBuffer();
}

GssLiveConn::GssLiveConn( char* server, unsigned short port, char* uid )
{
	m_isConnected = false;
	m_clientPullConn = NULL;
	m_stusRlt = 0;
	memset(m_bufferVideo, 0, MAX_AV_SIZE*sizeof(GssBuffer*));
	memset(m_bufferAudio, 0, MAX_AV_SIZE*sizeof(GssBuffer*));
	m_currNextIndexVideoInsert = 0;
	m_countsVideo = 0;
	m_curVideoIndex = 0;
	m_currNextIndexAudioInsert = 0;
	m_countsAudio = 0;
	m_curAudioIndex = 0;

	if(server)
		strcpy(m_server,server);
	m_port = port;
	if (uid)
		strcpy(m_uid,uid);

	InitVideoBuffer();
	InitAudioBuffer();
}

GssLiveConn::~GssLiveConn()
{
	if(m_clientPullConn)
	{
		gss_client_pull_destroy(m_clientPullConn);
		m_clientPullConn = NULL;
	}
	ClearVideoBuffer();
	ClearAudioBuffer();
}

bool GssLiveConn::Init( char* server, unsigned short port, char* uid )
{
	bool busc = false;
	do 
	{
		if(server == NULL || uid == NULL || port == 0)
			break;
		if(server)
			strcpy(m_server,server);
		m_port = port;
		if (uid)
			strcpy(m_uid,uid);
		busc = true;
	} while (0);

	return busc;
}

bool GssLiveConn::Start()
{
	bool busc = false;
	do 
	{
		int result;
		gss_pull_conn_cfg cfg;
		gss_pull_conn_cb cb;

		if(m_clientPullConn)
		{
			printf("client pull connection is not null");
			busc = true;
			break;
		}

		cfg.server = &m_server[0];
		cfg.port = m_port;
		cfg.uid = &m_uid[0];
		cfg.user_data = this;
		cfg.cb = &cb;

		cb.on_recv = &GssLiveConn::OnRecv;
		cb.on_disconnect = OnDisconnect;
		cb.on_connect_result= OnConnectResult;
		cb.on_device_disconnect= OnDeviceDisconnect;

		result = gss_client_pull_connect(&cfg, &m_clientPullConn); 
		m_stusRlt = result;
		if(result != 0)
		{
			printf("client_pull_connect_server return %d", result);
			m_isConnected = false;
			break;
		}
		else
		{
			m_isConnected = true;
		}

		busc = true;
	} while (0);

	return busc;
}

bool GssLiveConn::Stop()
{
	if(m_clientPullConn)
	{
		gss_client_pull_destroy(m_clientPullConn);
		m_clientPullConn = NULL;
		m_isConnected = false;
		return true;
	}
	return true;
}

bool GssLiveConn::IsConnected()
{
	return m_isConnected;
}

bool GssLiveConn::GetVideoFrame( unsigned char** pData, int &datalen )
{
	bool bSuc = false;
	if (m_countsVideo > 0 && pData && *pData == NULL)
	{
		*pData = m_bufferVideo[m_curVideoIndex]->m_buffer;
		datalen = m_bufferVideo[m_curVideoIndex]->m_bufferlen;
		bSuc = true;
	}
	return bSuc;
}

void GssLiveConn::FreeVideoFrame()
{
	m_lockVideo.Lock();
	IncVideoIndex();
	m_countsVideo--;
	m_lockVideo.Unlock();
}

bool GssLiveConn::GetAudioFrame( unsigned char** pData, int &datalen )
{
	bool bSuc = false;
	if (m_countsAudio > 0 && pData)
	{
		memcpy(pData,m_bufferAudio[m_curAudioIndex]->m_buffer,m_bufferAudio[m_curAudioIndex]->m_bufferlen);
		datalen = m_bufferAudio[m_curAudioIndex]->m_bufferlen;
		bSuc = true;
	}
	return bSuc;
}

void GssLiveConn::FreeAudioFrame()
{
	m_lockAudio.Lock();
	IncAudioIndex();
	m_countsAudio--;
	m_lockAudio.Unlock();
}

bool GssLiveConn::Send( unsigned char* pData, int datalen )
{
	return true;
}

void GssLiveConn::OnRecv( void *transport, void *user_data, char* data, int len, char type, unsigned int time_stamp )
{
	GssLiveConn* pConn = (GssLiveConn*)user_data;
	pConn->AddFrame((unsigned char*)data,len);
}

void GssLiveConn::OnDisconnect( void *transport, void* user_data, int status )
{
	GssLiveConn* pConn = (GssLiveConn*)user_data;
	pConn->m_isConnected = false;
	pConn->m_stusRlt = status;
	pConn->Stop();
}

void GssLiveConn::OnConnectResult( void *transport, void* user_data, int status )
{
	GssLiveConn* pConn = (GssLiveConn*)user_data;
	pConn->m_stusRlt = status;
	if(pConn->m_stusRlt != 0)
		pConn->Stop();
	else
		pConn->m_isConnected = true;
}

void GssLiveConn::OnDeviceDisconnect( void *transport, void *user_data )
{
	GssLiveConn* pConn = (GssLiveConn*)user_data;
	pConn->Stop();
}

void GssLiveConn::InitVideoBuffer()
{
	for (int i = 0; i < MAX_AV_SIZE; i++)
	{
		GssBuffer* tmpbuf = new GssBuffer();
		m_bufferVideo[i] = tmpbuf;
	}
}

void GssLiveConn::ClearVideoBuffer()
{
	for (int i = 0; i < MAX_AV_SIZE; i++)
	{
		GssBuffer* tmpbuf = m_bufferVideo[i];
		delete tmpbuf;
		m_bufferVideo[i] = NULL;
	}
}

void GssLiveConn::InitAudioBuffer()
{
	for (int i = 0; i < MAX_AV_SIZE; i++)
	{
		GssBuffer* tmpbuf = new GssBuffer(false);
		m_bufferAudio[i] = tmpbuf;
	}
}

void GssLiveConn::ClearAudioBuffer()
{
	for (int i = 0; i < MAX_AV_SIZE; i++)
	{
		GssBuffer* tmpbuf = m_bufferAudio[i];
		delete tmpbuf;
		m_bufferAudio[i] = NULL;
	}
}

bool GssLiveConn::AddVideoFrame( unsigned char* pData, int datalen )
{
	bool bsuc = false;
	do 
	{
		if (pData == NULL || datalen <= 0)
		{
			break;
		}
		m_lockVideo.Lock();
		if (m_countsVideo < MAX_AV_SIZE)
		{
			bsuc = m_bufferVideo[m_currNextIndexVideoInsert]->SetBuffer(pData,datalen);
			if(bsuc)
			{
				IncVideoNextInsertIndex();
				m_countsVideo++;
			}
		}
		m_lockVideo.Unlock();
	} while (false);

	return bsuc;
}

bool GssLiveConn::AddAudioFrame( unsigned char* pData, int datalen )
{
	bool bsuc = false;
	do 
	{
		if (pData == NULL || datalen <= 0)
		{
			break;
		}
		m_lockAudio.Lock();
		if (m_countsAudio < MAX_AV_SIZE)
		{
			bsuc = m_bufferAudio[m_currNextIndexAudioInsert]->SetBuffer(pData,datalen);
			if (bsuc)
			{
				IncAudioNextInsertIndex();
				m_countsAudio++;
			}
		}
		m_lockAudio.Unlock();
	} while (false);

	return bsuc;
}

bool GssLiveConn::AddFrame( unsigned char* pData, int datalen )
{
	bool bsuc = false;
	do 
	{
		if (pData == NULL || datalen <= 0)
		{
			break;
		}

		GP2pHead header;
		memcpy(&header,pData,sizeof(GP2pHead));
		//字节序 ?

		//? header.size ?= datalen - sizeof(GP2pHead)
		if (header.msgType == SND_VIDEO)
		{
			bsuc = AddVideoFrame(pData + sizeof(GP2pHead),datalen - sizeof(GP2pHead));
		}
		else if (header.msgType == SND_AUDIO)
		{
			bsuc = AddAudioFrame(pData + sizeof(GP2pHead), datalen - sizeof(GP2pHead));
		}
		else
		{
			//暂不处理
			break;
		}
	} while (0);

	return bsuc;
}

void GssLiveConn::IncVideoIndex()
{
	m_curVideoIndex++;
	if (m_curVideoIndex >= MAX_AV_SIZE)
	{
		m_curVideoIndex = 0;
	}
}

void GssLiveConn::IncVideoNextInsertIndex()
{
	m_currNextIndexVideoInsert++;
	if (m_currNextIndexVideoInsert >= MAX_AV_SIZE)
	{
		m_currNextIndexVideoInsert = 0;
	}
}

void GssLiveConn::IncAudioIndex()
{
	m_curAudioIndex++;
	if (m_curAudioIndex >= MAX_AV_SIZE)
	{
		m_curAudioIndex = 0;
	}
}

void GssLiveConn::IncAudioNextInsertIndex()
{
	m_currNextIndexAudioInsert++;
	if(m_currNextIndexAudioInsert >= MAX_AV_SIZE)
		m_currNextIndexAudioInsert = 0;
}